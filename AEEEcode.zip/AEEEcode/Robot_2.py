#Totally new
#pip install qiskit
#pip install qiskit-ibm-provider
#pip install qiskit-aer
#https://qiskit.org/providers/
import qiskit.compiler as qcompiler;
from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit;
from qiskit_aer import AerSimulator;
from qiskit.visualization import plot_histogram
#https://quantum-computing.ibm.com/account?needs_refill=true IBMid peppino.fazio@unive.it psw Ce.............737373
from qiskit_ibm_provider import IBMProvider;
from qiskit_ibm_provider import least_busy;
import heapq;#for quantum statistics
import operator;#for quantum statistics
#import time#For sleep count
from datetime import date#For time management
from datetime import timedelta#for evaluating 
from datetime import datetime#for elapsed seconds evaluation
import os#For directory manipulation
#import sys#For scrolling text
import numpy as np#for arrays/list pip install NumPy
import matplotlib.pyplot as plt#pip install matplotlib

from matplotlib.figure import Figure
import matplotlib.ticker as ticker
from matplotlib import dates
from matplotlib.colors import to_rgba
import requests#For HTTP Fronius GET values
import psutil#For memory utilization monitoring pip install psutil 
import gc#For memory deallocation
import icmplib#For pinging pip install icmplib
import math
import logging
import sys
#From scratch
from time import time
from time import localtime
from time import sleep
from time import strftime
#From examples
from os.path import dirname, join
from threading import Thread
########################################################################################

classic=True;#If false, quantum circuits are used

#Robots sensing distance (autonomous radius)
sensing=20;
#Map multiplying factors
Kx=30;
Ky=30; 
#MAP dimensions in meters
X=Kx*sensing;
Y=Ky*sensing;
#Robots coverage radius for RF
coverage=100;#This is for packets exchange (radio coverage)
#id_mul (for differentiating robots ids)
id_mul=100;

#Robots number
N=15;
#For local writing (it is just the current path for future writing of files)
abs_path='./'
#Target coordinates (placed randomly for now into the code)
target_x=0;
target_y=0;
target_i=0;#coloumn (associated to x)
target_j=0;#row (associated to y)
#Packets codes legend (payload)
#0 HELLO
#1 target_found by sender
#struct for target position broadcasting
#Mobility parameters (constant speed for now, the model can be extended with acceleration/deceleration)
vx=2;#m/s
low_vx=0.4;#m/s when approaching the target
#When target found, broadcast position every BC seconds
BC=5;
#For quantum broadcasting
BCQ=5;

#Obstacle coordinates
#Target coordinates (placed randomly for now into the code)
obs_x=0;
obs_y=0;
obs_i=0;#coloumn (associated to x)
obs_j=0;#row (associated to y)

rewards_vector=[];

if (not(classic)):
    #Quantum circuit
    #Starting from this link https://pypi.org/project/qiskit-ibmq-provider/
    print("Connecting to IBM quantum computing provider...")
    IBMProvider.save_account(token='e9caf0f4fa730c9475f25f80b949f734214be058b6379b71388d485a4c2d1c151db573d42987f6ca21f681717746d2d9c4771599d03855bb87dbbbfb822092e6', overwrite=True);
    provider=IBMProvider();
    print("DONE! Creating quantum circuit...");
    q = QuantumRegister(5, 'q') # qubits
    m2 = ClassicalRegister(1, 'c2') # classical bits (separated is better)
    m3 = ClassicalRegister(1, 'c3')
    m4 = ClassicalRegister(1, 'c4')
    #Quantum circuits: 1 to reach the target, 2 to return to the base
    qc1 = QuantumCircuit(q, m2, m3, m4) # to reach the target
    qc2 = QuantumCircuit(q, m2, m3, m4) # to get back to the nest, not used for now
    print("Created!");
    #For IBM job management
    #backend = least_busy(
    #    provider.backends(
    #        simulator=False, filters=lambda b: b.configuration().n_qubits >= 5
    #    )
    #)
    backend = AerSimulator();
    #Number of quantum "calls" per node
    n_shots=2048;
    #Number of states
    num_most_prob_states = 4
    #In order to manage just one call to the IBM provider
    circuit_started=False;

#We assume, for now, that the weights of all robots are known globally (then we have to exchange them in order to realize a distributed communication) 
weights_list=[];
for i in range(N):
    weights_list.append(0)
#print("Weights: ", weights_list);

#For creating the raw plots
fig, ax = plt.subplots()

#Messages class (simple packet structure)
class routingPacket:
    source_id=0;
    destination_id=0;#If -1 it is a broadcast
    content=[];
    quantum=False;
    content_size=0;
    def __init__(self,source_id, destination_id, content, quantum):
        self.source_id=source_id
        self.destination_id=destination_id
        self.content=content
        self.quantum=quantum
#End of Packet class

#Main object
class robot:
    #I declare the variable here to gain memory wastage (they are always the same without creating new ones everytime)
    #Robot unique identifier
    id=0;
    #Current position in the map
    pos_x=0;
    pos_y=0;
    #Next position to be reached
    next_pos_x=0;
    next_pos_y=0;
    #sensing range (meters)
    sensing_distance=0;
    #main thread
    thr=None;
    #Classic BroadCasting thread
    BC_thr=None;
    #Quantum BroadCasting thread
    BCQ_thr=None;
    #To know it BC has started
    BC_started=False;
    #Automata status
    status=0;#0 created, 1 moving for target and checking messages, 2 target found by myself
    #List of all robots (shared structure, read only)
    robot_list=[];
    #Boolean if the robot list has been acquired
    list_acquired=False;
    #Public message list (to check if any message is there, read/write mode)
    message_queue=[];
    #Lock in writing mode
    message_queue_lock=False;
    #Boolean to know if it has to move randomly
    new_position=True;
    #Matrix of already visited areas
    Map_matrix = None;
    #previous time
    prev_time=0;
    #current_time
    curr_time=0;
    #used variables declared here for saving memory
    i=None;
    ii=None;
    jj=None;
    j=None;
    k=None;
    x_n=None;
    y_n=None;
    p=None;
    distance=None;
    target_distance=None;
    obstacle_distance=None;
    obstacle_detected=None;
    #For mobility management
    elapsed_time=None;
    seconds=None;
    #For the line equation
    x0=None;
    y0=None;
    x1=None;
    y1=None;
    m=None;
    q=None;
    delta_x=None;
    #Go to target (another robot found the target and broadcasted the position, so this robot has to go there)
    go_to=False;
    
    #Quantum actions
    weight=0;#normalized from 0 to 1 in function of sensing distance
    #Content or type of packet
    packet_content=[];
    #Quantum parameters
    alpha_x=0;
    alpha_y=0;
    beta_x=0;
    beta_y=0;
    gamma=0;
    delta=0;
    #Job supporting structures
    vector0=[];
    vector1=[];
    vector2=[]; 
    normalized_v0 = 0;
    normalized_v1 = 0;
    normalized_v2 = 0;
    #Results of quantum call (shots probabilities)
    results=None;
    outcome0=0;
    outcome1=0;
    
    #The needed constructor    
    def __init__(self,id):
        self.id=id;
        self.sensing_distance=sensing;
        self.thr=Thread(target=self.finite_state)
        self.BC_thr=Thread(target=self.BC_broadcasting)
        self.BCQ_thr=Thread(target=self.BCQ_broadcasting)
        self.Map_matrix = np.zeros((Kx, Ky))
        
    #For creating the relationship with the array of all robots and the array of sent messages
    def acquire_list(self, array1, array2, message_queue_lock):
        self.robot_list=array1;
        self.message_queue=array2;
        #print("Robot: ", self.id, " created and acquired the list of robots!");
        self.list_acquired=True;
        self.message_queue_lock=message_queue_lock;
    
    def BC_broadcasting(self):
        while (True):
            #print("STARTEDin");
            if(not(self.message_queue_lock)):
                #print("BC started!");
                self.message_queue_lock=True;
                self.packet_content=[target_x, target_y, self.weight];
                self.p=routingPacket(self.id, -1, self.packet_content, not(classic));#destination -1 means to all
                self.p.content_size=3;#3 fields in the payload
                self.message_queue.append(self.p);
                self.message_queue_lock=False;
                #print("Robot ",self.id, " broadcasted target position: (",target_x,", ",target_y,").");
                #It does not move but continues to broadcast position
                sleep(BC);
    
    def BCQ_broadcasting(self):
        while (True):
            #print("STARTEDin");
            if(not(self.message_queue_lock)):
                #print("BC started!");
                self.message_queue_lock=True;
                #print("next_pos_x: ", , ", next_pos_y: ", , ", next_weight: ", self.delta);
                self.packet_content=[self.alpha_x*X, self.alpha_y*Y, self.delta];
                self.p=routingPacket(self.id, -1, self.packet_content, True);#destination -1 means to all
                self.p.content_size=3;#3 fields in the payload
                self.message_queue.append(self.p);
                self.message_queue_lock=False;
                rewards_vector.append(self.delta);
                #print("Robot ",self.id, " broadcasted target position: (",target_x,", ",target_y,").");
                #It does not move but continues to broadcast position
                sleep(BCQ);    
    
        
    #To print on console the matrix of visited sub-areas
    #0 not visited
    #1 visited as temporary place or chosen to be reached as next position
    #2 arrived there to choose another position
    def print_matrix(self):
        sleep(np.random.uniform(0.1, 1))
        #print("Matrix for Robot: ",self.id);
        for self.ii in range (Kx):
            #None operation just to comment
            a=0;
            #print(self.Map_matrix[:,self.ii]);        
       
    #For quantum statistics   
    def eval_outcome(self, most_prob_dict, n_outcome):
        mapped_weights0 = list(map(lambda res: int(res[n_outcome*2])*most_prob_dict[res], most_prob_dict))
        return sum(mapped_weights0)/sum(most_prob_dict.values())
        
    #For evaluating the new reward (weight) based on quantum results
    def reward(self, target_x, target_y, betax, betay):
        return 1 - ((target_x/X - betax)**2 + (target_y/Y - betay)**2)**0.5;
    
    #main robot behavior
    def finite_state(self):
        self.prev_time=datetime.now();
        #Borning
        self.ii=0;
        self.Map_matrix[target_j,target_i]=True;
        self.Map_matrix[obs_j,obs_i]=True;
        while (self.ii==0):
            self.i=np.random.randint(0, Ky-1);
            self.j=np.random.randint(0, Kx-1);
            #to make robots not borning immediately near the target position
            if (not(self.i==target_i))or(not(self.j==target_j)):
                self.ii=1;#to exit
                self.Map_matrix[self.j,self.i]=True;
                self.print_matrix();
                self.pos_x=float(self.j*sensing)+np.random.uniform(0.2, sensing/2);
                self.pos_y=float(self.i*sensing)+np.random.uniform(0.2, sensing/2);
                #############################################################################################################
                #if (self.id==0):
                #    self.pos_x=target_x;
                #    self.pos_y=target_y;
                #############################################################################################################    
        #print("Robot ",self.id," position: ",self.pos_x, ", ",self.pos_y, " with i: ", self.i, " j: ", self.j);
        if ((self.status==0)and(self.list_acquired)):#created
            self.k=0;
            #print("Robot: ",self.id," sees ",len(self.robot_list), " elements in the robot list!");
            for self.ii in range(len(self.robot_list)):
                #print(self.ii);
                if not(self.ii==self.id):
                    self.p=routingPacket(self.id, self.robot_list[self.ii].id,0, not(classic));
                    self.p.content_size=1;
                    self.message_queue.append(self.p);
                    self.k=self.k+1;
        
        #print("Robot: ",self.id," enqueued ",self.k," HELLO packets.");  
        #print("Robot: ",self.id," sees ",len(self.message_queue), " elements in the message list!");
        self.status=1;#checking messages and moving
        #print("Robot ",self.id," bootup finished...");
        sleep(np.random.uniform(0.2, 0.5));
        #Checking messages and moving
        
        while((self.status==1)and(not(self.go_to))):
            #Checking message list for a packet destined to it
            if (self.message_queue_lock==False):
                self.message_queue_lock=True;
                self.ii=0;
                
                #Check for new messages
                while (self.ii < (len(self.message_queue))):
                    self.p=self.message_queue[self.ii];
                    if ((self.p.destination_id==self.id)or(self.p.destination_id==-1)):#a packet destined to it (unicast or broadcast)
                        #let us check the coverage radius
                        self.x_n=self.robot_list[int(self.p.source_id/id_mul)].pos_x;
                        self.y_n=self.robot_list[int(self.p.source_id/id_mul)].pos_y;
                        self.distance=math.sqrt((self.pos_x-self.x_n)*(self.pos_x-self.x_n)+(self.pos_y-self.y_n)*(self.pos_y-self.y_n));
                        if (self.distance<=coverage):
                            print("Robot ",self.id, " received a message from robot: ",self.p.source_id, ", under a coverage of: ", self.distance, " meters, with payload size of: ",self.p.content_size,".");
                            #Let us control the payload
                            if (self.p.content==1):
                                self.go_to=True;
                                self.new_position=True;
                            #Received an array as payload
                            elif (self.p.content_size==3):
                                print ("Robot ",self.id, " received a BC message from robot: ",self.p.source_id, " indictating target coordinates!");
                                self.status=2;
                                self.weight=0;
                        #Discard the message because not under coverage
                        else:
                            a=0;#dummy
                            #print("Robot ",self.id, " discarded a message from robot: ",self.p.source_id, " because out of coverage: (", self.distance, ") meters.");
                        #Remove the message from the array
                        del self.message_queue[self.ii];
                        self.ii=self.ii-1;
                    self.ii=self.ii+1;
                    #Received a broadcasted packet for going to target                      
                self.message_queue_lock=False;
                
            #Mobility management    
            self.target_distance=math.sqrt((self.pos_x-target_x)*(self.pos_x-target_x)+(self.pos_y-target_y)*(self.pos_y-target_y));  
            self.obstacle_distance=math.sqrt((self.pos_x-obs_x)*(self.pos_x-obs_x)+(self.pos_y-obs_y)*(self.pos_y-obs_y)); 
            if (self.obstacle_detected):
                if (self.obstacle_distance>sensing+5):#just to be sure that it is going wawy from it
                    self.obstacle_detected=False;#This to avoid that if the robot "sees" again the obstacle it will go on it because it has already sensed and avoided it
            if ((self.target_distance<sensing)and(not(self.go_to))): #Target found
                #print("Robot ",self.id, " found the target from its position: (",self.pos_x,", ",self.pos_y,").");
                self.status=2;
                self.weight=1-(self.target_distance/sensing);
                self.ii=int(self.id/id_mul);
                weights_list[self.ii]=self.weight;
                #Just to have the chance to change the code
                if (classic):
                    self.go_to=True;
                else:
                    self.go_to=True;
            elif ((self.obstacle_distance<sensing)and(not(self.obstacle_detected))):
                self.new_position=True;
                self.obstacle_detected=True;
                #print("Robot: ",self.id, " detected the obstacle and changes direction.");
                self.Map_matrix[obs_j,obs_i]=True;#avoids to go back to that point (setting it as visited)              
            else: #target still not found, it has still to move   
                if (self.new_position):#a new position needs to be reached
                    self.new_position=False;
                    if (self.go_to):#received the message from another robot about the position
                        self.next_pos_x=target_x;
                        self.next_pos_y=target_y;
                    #This makes robot stuck
                    #if (self.obstacle_detected):
                    #    self.obstacle_detected=False;
                    else:
                        self.k=0;
                        #Here the choice is completely random (except for the matrix information), which should be common and not one for each robot...
                        while (self.k==0):
                            self.i=np.random.randint(0, Ky-1);
                            self.j=np.random.randint(0, Kx-1);
                            if (not(self.Map_matrix[self.j,self.i])):
                                self.k=1;
                                self.Map_matrix[self.j,self.i]=True;
                        #The center of the (i,j) grid element
                        self.next_pos_x=float(self.j*sensing)+sensing/2;
                        self.next_pos_y=float(self.i*sensing)+sensing/2;
                    if(self.next_pos_x+sensing>X):
                        print("Warning, next x position for Robot ",self.id, " out of bounds!");
                        self.next_pos_x=X;
                    if(self.next_pos_y+sensing>Y):
                        print("Warning, next y position for Robot ",self.id, " out of bounds!");
                        self.next_pos_y=Y;
                    #self.next_pos_x=np.random.uniform(2, X-2);#+-2 to have the possibility to recognize the map border
                    #self.next_pos_y=np.random.uniform(2, Y-2);#+-2 to have the possibility to recognize the map border
                    #Define the line equation
                    #The random centimeters are added to avoid m=0 and/or null denominator
                    self.x1=self.next_pos_x+np.random.uniform(0.01, 0.05);
                    self.x0=self.pos_x+np.random.uniform(0.01, 0.05);
                    self.y1=self.next_pos_y+np.random.uniform(0.01, 0.05);
                    self.y0=self.pos_y-np.random.uniform(0.01, 0.05);
                    self.m=(self.y1-self.y0)/(self.x1-self.x0);
                    self.q=(self.y0*self.x1-self.x0*self.y1)/(self.x1-self.x0); 
                    #print("Robot ",self.id, " new position: (",self.next_pos_x,self.next_pos_y,"), with m: ",self.m," and q: ",self.q);
                else:
                    #print("Robot ",self.id, " moving to: (",self.next_pos_x,self.next_pos_y,").");
                    self.curr_time=datetime.now();
                    self.elapsed_time=self.curr_time-self.prev_time;
                    self.prev_time=self.curr_time;
                    self.seconds=self.elapsed_time.total_seconds();
                    #print("Robot ",self.id, " seconds elapsed: ",self.seconds);
                    #update position
                    #Assumed to go to the right
                    self.delta_x=vx*self.seconds;
                    #print("Robot ",self.id, " delta_x: ",self.delta_x);
                    if (self.next_pos_x<self.pos_x):
                        #it should go to the left
                        self.delta_x=-self.delta_x;
                    self.pos_x=self.pos_x+self.delta_x;
                    #self.pos_y=self.pos_y+self.m*self.delta_x+self.q;
                    self.pos_y=self.m*self.pos_x+self.q;
                    #Bounds respectation conditions
                    if(self.pos_x+sensing>X-0.1):
                        print("Warning, current x position for Robot ",self.id, " out of bounds!");
                        self.pos_x=X-sensing-0.1;
                        self.new_position=True;
                    if(self.pos_y+sensing>Y-0.1):
                        print("Warning, current y position for Robot ",self.id, " out of bounds!");
                        self.pos_y=Y-sensing-0.1;
                        self.new_position=True;
                    if(self.pos_x-sensing<0):
                        print("Warning, current x position for Robot ",self.id, " out of bounds!");
                        self.pos_x=sensing;
                        self.new_position=True;
                    if(self.pos_y-sensing<0):
                        print("Warning, current y position for Robot ",self.id, " out of bounds!");
                        self.pos_y=sensing;
                        self.new_position=True;    
                    #let us see if the new position has been reached or if it has still to move along the line
                    self.distance=math.sqrt((self.pos_x-self.next_pos_x)*(self.pos_x-self.next_pos_x)+(self.pos_y-self.next_pos_y)*(self.pos_y-self.next_pos_y));
                    rewards_vector.append(0);
                    if (self.distance<0.3):
                        #Destination reached, new point is needed
                        self.Map_matrix[self.j, self.i]=2;
                        #print("Robot ",self.id," found the position in (",self.i,self.j,") and matrix set to 2!");
                        self.new_position=True; 
                        self.pos_x=self.next_pos_x;
                        self.pos_y=self.next_pos_y;
                        self.ii=int((self.pos_x-sensing/2)/sensing);
                        self.jj=int((self.pos_y-sensing/2)/sensing);
                        if (self.Map_matrix[self.jj, self.ii]==0):
                            self.Map_matrix[self.jj, self.ii]=1;#Robot is passing there so it can be considered as a visited area
            sleep(np.random.uniform(0.2, 1.5));
            #if (self.go_to):
                #self.go_to=False;
                #break;#While status==1
            #print("Robot: ",self.id, " moved to (",self.pos_x,self.pos_y,").");
            #if (self.id==0):
            #self.print_matrix();
            if (len(self.message_queue)==0):
                self.k=0;#no action
                #print("No messages into the queue.... simulation stopped!");
                #sys.exit();
                    
        #End while status 
        #Moving to target and stop
        while(self.status==2):
            #No quantum activity
            if (classic): 
                #print("Robot: ", self.id, " in Status 2 with Classical approach!");
                self.x1=target_x#+np.random.uniform(0.0001, 0.0005);
                self.x0=self.pos_x#+np.random.uniform(0.0001, 0.0005);
                self.y1=target_y#+np.random.uniform(0.0001, 0.0005);
                self.y0=self.pos_y#-np.random.uniform(0.0001, 0.0005);
                self.ii=self.x1-self.x0;
                if (self.ii==0):
                    self.ii=0.0001;#avoids division by zero
                self.m=(self.y1-self.y0)/(self.x1-self.x0);
                self.q=(self.y0*self.x1-self.x0*self.y1)/(self.x1-self.x0); 
                #Target has been found! Move to it and continue send messages with weight
                print("Robot: ",self.id, " found the target (directly or undirectly) and is moving toward it!");
                self.curr_time=datetime.now();
                self.elapsed_time=self.curr_time-self.prev_time;
                self.prev_time=self.curr_time;
                self.seconds=self.elapsed_time.total_seconds();
                #vx has been divided by 5 in order to slow down (to be modeled by real mobility models
                if (self.ii>0):
                    self.delta_x=(low_vx)*self.seconds;
                else:
                    self.delta_x=-(low_vx)*self.seconds;
                self.pos_x=self.pos_x+self.delta_x;
                #self.pos_y=self.pos_y+self.m*self.delta_x+self.q;
                self.pos_y=self.m*self.pos_x+self.q;
                self.weight=1-self.distance/sensing;
                #Maybe the robot received the BC message from another one and the target is still not under sensing radius, so it still does not see the target
                if (self.weight<0):
                    self.weight=0;
                weights_list[int(self.id/id_mul)]=self.weight;
                self.distance=math.sqrt((self.pos_x-target_x)*(self.pos_x-target_x)+(self.pos_y-target_y)*(self.pos_y-target_y));
                if (self.distance<BC*low_vx+0.01):
                    self.status=3;#Arrived, stop moving and broadcasting!
                    self.weight=1;
                    weights_list[int(self.id/id_mul)]=self.weight;
                    self.pos_x=target_x;
                    self.pos_y=target_y;
                print("Robot: ",self.id, " weight: ",self.weight,", at distance: ",self.distance,"m, with BC*vx:",BC*low_vx,"m.");
                sleep(np.random.uniform(0.2, 0.4));
                #It has to broadcast its position and call the other (under coverage, if any) to arrive
                if (not(self.BC_started)):
                    self.BC_thr.start();
                    #print("STARTED");
                    self.BC_started=True;
            #quantum activity
            else:
                print("Robot: ", self.id, " in Status 2 with Quantum approach!");
                #alpha x e y positions
                #beta 1-alpha
                #delta weight
                #gamma 1-delta
                self.beta_x=self.pos_x/X;
                self.beta_y=self.pos_y/Y;
                self.alpha_x=1-self.beta_x;
                self.alhpa_y=1-self.beta_y;
                self.delta=self.weight;
                self.gamma=1-self.weight;                
                self.vector0=[self.alpha_x, self.beta_x]
                self.vector1=[self.alpha_y, self.beta_y]
                self.vector2=[self.gamma, self.delta]
                normalized_v0 = self.vector0/np.linalg.norm(self.vector0)
                normalized_v1 = self.vector1/np.linalg.norm(self.vector1)
                normalized_v2 = self.vector2/np.linalg.norm(self.vector2)
                
                # direct initialization with amplitudes vector
                qc1.initialize(normalized_v0, q[0])
                qc1.initialize(normalized_v1, q[1])
                qc1.initialize(normalized_v2, q[2])
                
                # this is the core code
                qc1.barrier(q)
                qc1.ccx(q[0],q[1],q[3])
                qc1.ccx(q[0],q[1],q[4])
                qc1.reset(q[3])
                qc1.reset(q[4])
                qc1.ccx(q[0],q[2],q[3]) 
                qc1.ccx(q[1],q[2],q[4])
                qc1.x(q[2])
                qc1.ch(q[2],q[3])
                qc1.ch(q[2],q[4])
                qc1.x(q[2])
                qc1.barrier(q)

                # perform measurements and store them in classical bits
                qc1.measure(q[2],m2[0])
                qc1.measure(q[3],m3[0])
                qc1.measure(q[4],m4[0])
                
                #print(qc1);
                global circuit_started;
                global backend;
                global circuit_started;
                global n_shots;
                global num_most_prob_states;
                if (not(circuit_started)):
                    print("IBM provider called by Robot: ",self.id);
                    circuit_started=True;
                    #print("A");
                    mapped_circuit = qcompiler.transpile(qc1, backend=backend)
                    #print("B");
                    job = backend.run(mapped_circuit, shots=n_shots);
                    #print("C");
                    self.results=job.result().get_counts()
                    #print(self.results)
                    #plot_histogram(job.result().get_counts())
                    circuit_started=False;
                    #To be random
                    sleep(2);
                    #print("D");
                    # https://docs.python.org/3/library/heapq.html: 
                    # heapq.nlargest(n, iterable, key=None) returns a list with the n largest element of iterable
                    most_prob_dict = dict(heapq.nlargest(num_most_prob_states, self.results.items(), key=operator.itemgetter(1)))
                    #print(f"{num_most_prob_states} most probable states: {most_prob_dict}")
                    self.outcome0, self.outcome1 = self.eval_outcome(most_prob_dict, 0), self.eval_outcome(most_prob_dict, 1)
                    #print(f"outcome0: {outcome0:.2f}\noutcome1: {outcome1:.2f}")
                    #Recall that:
                    #alpha x e y = positions
                    #beta = 1-alpha
                    #delta = weight
                    #gamma = 1-delta
                    #New coordinates after quantum analysis
                    self.alpha_y=1-self.outcome0;
                    self.beta_y = 1-self.alpha_y; 
                    self.alpha_x=1-self.outcome1;
                    self.beta_x=1-self.alpha_x# for x
                    #New rewards
                    self.delta = self.reward(target_x, target_y, self.beta_x, self.beta_y);
                    self.gamma = 1 - self.delta
                    rewards_vector.append(self.delta);
                    print("Robot: ",self.id, " stops and broadcasts next_pos_x: ", self.beta_x*X, ", next_pos_y: ", self.beta_y*Y, ", next_weight: ", self.delta);
                    #It stops but starts to send BCQ messages to the others under the coverage
                    '''
                    self.x1=self.alpha_x*X#+np.random.uniform(0.0001, 0.0005);
                    self.x0=self.pos_x#+np.random.uniform(0.0001, 0.0005);
                    self.y1=self.alpha_y*Y#+np.random.uniform(0.0001, 0.0005);
                    self.y0=self.pos_y#-np.random.uniform(0.0001, 0.0005);
                    self.ii=self.x1-self.x0;
                    if (self.ii==0):
                        self.ii=0.0001;#avoids division by zero
                    self.m=(self.y1-self.y0)/(self.x1-self.x0);
                    self.q=(self.y0*self.x1-self.x0*self.y1)/(self.x1-self.x0); 
                    #Target has been found! Move to it and continue send messages with weight
                    print("Robot: ",self.id, " found the target and is moving toward it!");
                    self.curr_time=datetime.now();
                    self.elapsed_time=self.curr_time-self.prev_time;
                    self.prev_time=self.curr_time;
                    self.seconds=self.elapsed_time.total_seconds();
                    #vx has been divided by 5 in order to slow down (to be modeled by real mobility models
                    if (self.ii>0):
                        self.delta_x=(low_vx)*self.seconds;
                    else:
                        self.delta_x=-(low_vx)*self.seconds;
                    self.pos_x=self.pos_x+self.delta_x;
                    #self.pos_y=self.pos_y+self.m*self.delta_x+self.q;
                    self.pos_y=self.m*self.pos_x+self.q;
                    self.weight=self.delta;
                    weights_list[int(self.id/id_mul)]=self.weight;
                    self.distance=math.sqrt((self.pos_x-target_x)*(self.pos_x-target_x)+(self.pos_y-target_y)*(self.pos_y-target_y));
                    if (self.distance<BC*low_vx+0.01):
                        self.status=3;#Arrived, stop moving and broadcasting?!
                        self.delta=1;
                        self.weight=1;
                        weights_list[int(self.id/id_mul)]=self.weight;
                        self.pos_x=target_x;
                        self.pos_y=target_y;
                    print("Robot: ",self.id, " weight: ",self.weight,", at distance: ",self.distance,"m, with BC*vx:",BC*low_vx,"m.");
                    sleep(np.random.uniform(0.2, 0.4));
                    '''
                    #It has to broadcast its position and call the other (under coverage, if any) to arrive
                    
                    if (not(self.BC_started)):
                        self.BCQ_thr.start();
                        #print("STARTED");
                        self.BC_started=True;  
        #End status 2
        
        while(self.status==3):
            #DO what we want! This code is just dummy
             self.pos_x=target_x;
             self.pos_y=target_y;
             #print("Status 3");
             #self.BC_broadcasting();
             sleep(BC);
                  
    #Each robot starts as an independent thread
    def start(self):
        self.thr.start()
    
#class FHEM(App):
class swarm:
    dim_x=X;
    dim_y=Y;
    n_robot=N;
    robot_array=[]
    message_list=[];
    message_list_lock=False;
    thr=None;
    curr=None;
    #12 basic colors and then they repeat themselves (MAX 102 robots)
    colors=["black", "cyan", "olive", "gray", "pink", "brown", "purple", "orange", "green", "blue", "yellow", "red",
    "black", "cyan", "olive", "gray", "pink", "brown", "purple", "orange", "green", "blue", "yellow", "red",
    "black", "cyan", "olive", "gray", "pink", "brown", "purple", "orange", "green", "blue", "yellow", "red",
    "black", "cyan", "olive", "gray", "pink", "brown", "purple", "orange", "green", "blue", "yellow", "red",
    "black", "cyan", "olive", "gray", "pink", "brown", "purple", "orange", "green", "blue", "yellow", "red",
    "black", "cyan", "olive", "gray", "pink", "brown", "purple", "orange", "green", "blue", "yellow", "red",
    "black", "cyan", "olive", "gray", "pink", "brown", "purple", "orange", "green", "blue", "yellow", "red",
    "black", "cyan", "olive", "gray", "pink", "brown", "purple", "orange", "green", "blue", "yellow", "red"]
    ind=None;
    def __init__(self):
        #Creating robots
        for self.ind in range(self.n_robot): 
            #Ids are 0, 100, 200, 300, 400....
            print("ind:",self.ind*id_mul)
            self.curr=robot(self.ind*id_mul);
            self.robot_array.append(self.curr);
        print("Robots created!")
        
        #Simulating neighbor recognition and starting threads
        for self.ind in range(self.n_robot): 
            self.robot_array[self.ind].acquire_list(self.robot_array, self.message_list, self.message_list_lock);
            #print("Robot: ", self.robot_array[self.ind].id, " acquired the topological list!")
            self.robot_array[self.ind].start();
            sleep(1);
 #End of the core function
        
if __name__ == '__main__':
    
    #Target placement
    target_i=np.random.randint(0, Ky-1);
    target_j=np.random.randint(0, Kx-1);
    target_x=target_j*sensing+sensing/2-0.5;
    target_y=target_i*sensing+sensing/2-0.5;
    print("Target placed at (",target_x,", ",target_y,"), with (j,i): (",target_j,", ",target_i,").");
    #Obstacle placement
    print("Deploying obstacle...")
    obs_i=target_i;
    obs_j=target_j; 
    #It should be deployed in a different place than the target
    while ((obs_i==target_i)and(obs_j==target_j)):
        obs_i=np.random.randint(0, Ky-1);
        obs_j=np.random.randint(0, Kx-1);
    obs_x=obs_j*sensing+sensing/2-0.5;
    obs_y=obs_i*sensing+sensing/2-0.5;
    sleep(1);
    print("Obstacle placed at (",obs_x,", ",obs_y,")");
    #Swarm
    SW=swarm();
    print("Swarm created... deploying target.");
    sleep(1);#Simulating the delay for target deployment (robots should be created before for code issues)
    
    while(True):
        plt.cla()
        ax.set_xlim(0, X)
        ax.set_ylim(0, Y)
        ax.plot(target_x,target_y, marker="o", color="red")
        ax.plot(obs_x,obs_y, marker="s", color="black", markersize=15)
        for ind in range(SW.n_robot):
            ax.plot(SW.robot_array[ind].pos_x,SW.robot_array[ind].pos_y, marker="o", color=SW.colors[ind])
            #Sensing area
            circle1 = plt.Circle((SW.robot_array[ind].pos_x,SW.robot_array[ind].pos_y), sensing, color=SW.colors[ind], fc='None')
            #Coverage area
            circle2 = plt.Circle((SW.robot_array[ind].pos_x,SW.robot_array[ind].pos_y), coverage, color=SW.colors[ind], fc='None', ls='--')
            plt.gca().add_patch(circle1)
            plt.gca().add_patch(circle2)
            #plt.scatter(SW.robot_array[ind].pos_x,SW.robot_array[ind].pos_y, s=sensing, facecolors='none', edgecolors=SW.colors[ind])
        fig.canvas.draw()
        plt.pause(1)
        #print(weights_list);
        #print(rewards_vector);
        
        
      