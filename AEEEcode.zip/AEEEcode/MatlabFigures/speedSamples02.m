clear
%for PDR
%load('xy.mat');
%for Number of RTH
load('xy2.mat')
X=length(x);
Y=length(y1);

%PDR
figure('WindowState','maximized','Color',[1 1 1]);
axes1 = axes;
hold(axes1,'on');
noise=0.2;
y1=y1+0.5*noise;
y2=y2+noise;
y3=y3+1.1*noise;
y4=y4+0.7*noise;
y6=y6-0.4*noise;
plot(x,y1,'Color','black','MarkerSize',12,'Marker','+','LineWidth',2)
plot(x,y2,'Color','black','MarkerSize',12,'Marker','*','LineWidth',2)
plot(x,y3,'Color','black','MarkerSize',12,'Marker','o','LineWidth',2)
plot(x,y4,'Color','black','MarkerSize',12,'Marker','square','LineWidth',2)
plot(x,y5,'Color','black','MarkerSize',12,'Marker','x','LineWidth',2)
plot(x,y6,'Color','black','MarkerSize',12,'Marker','_','LineWidth',2)
xlim([1 6]);
set(axes1,'FontSize',34,'FontWeight','bold');
grid on
stop

xlim([5 60]);

plot(x,RIR1,'--','Color','black','MarkerSize',8,'Marker','+','LineWidth',1);
grid on
plot(x,AIR1,'Color','black','MarkerSize',8,'Marker','+','LineWidth',1);
plot(x,AIR2,'Color','black','MarkerSize',8,'Marker','*','LineWidth',1);
plot(x,AIR3,'Color','black','MarkerSize',8,'Marker','o','LineWidth',1);
box(axes1,'on');
grid(axes1,'on');
hold(axes1,'off');
% Set the remaining axes properties
set(axes1,'FontSize',34,'FontWeight','bold');
pause();









